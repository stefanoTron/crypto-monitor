webpackHotUpdate(0,{

/***/ "../node_modules/@haiku/core/dom/react/index.js":
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) Haiku 2016-2018. All rights reserved.
 */

module.exports = __webpack_require__("../node_modules/@haiku/core/lib/adapters/react-dom/index.js").default;


/***/ }),

/***/ "../node_modules/@haiku/core/lib/adapters/react-dom/EventsDict.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) Haiku 2016-2018. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// tslint:disable-next-line:variable-name
var EventsDict = {};
var eventsList = [
    'onAbort',
    'onAnimationEnd',
    'onAnimationIteration',
    'onAnimationStart',
    'onBlur',
    'onCanPlay',
    'onCanPlayThrough',
    'onChange',
    'onClick',
    'onCompositionEnd',
    'onCompositionStart',
    'onCompositionUpdate',
    'onContextMenu',
    'onCopy',
    'onCut',
    'onDoubleClick',
    'onDrag',
    'onDragEnd',
    'onDragEnter',
    'onDragExit',
    'onDragLeave',
    'onDragOver',
    'onDragStart',
    'onDrop',
    'onDurationChange',
    'onEmptied',
    'onEncrypted',
    'onEnded',
    'onError',
    'onFocus',
    'onInput',
    'onKeyDown',
    'onKeyPress',
    'onKeyUp',
    'onLoad',
    'onLoadedData',
    'onLoadedMetadata',
    'onLoadStart',
    'onMouseDown',
    'onMouseEnter',
    'onMouseLeave',
    'onMouseMove',
    'onMouseOut',
    'onMouseOver',
    'onMouseUp',
    'onPaste',
    'onPause',
    'onPlay',
    'onPlaying',
    'onProgress',
    'onRateChange',
    'onScroll',
    'onSeeked',
    'onSeeking',
    'onSelect',
    'onStalled',
    'onSubmit',
    'onSuspend',
    'onTimeUpdate',
    'onTouchCancel',
    'onTouchEnd',
    'onTouchMove',
    'onTouchStart',
    'onTransitionEnd',
    'onVolumeChange',
    'onWaiting',
    'onWheel',
];
for (var i = 0; i < eventsList.length; i++) {
    var name_1 = eventsList[i];
    EventsDict[name_1] = 'func';
    EventsDict[name_1 + 'Capture'] = 'func';
}
exports.default = EventsDict;
//# sourceMappingURL=EventsDict.js.map

/***/ }),

/***/ "../node_modules/@haiku/core/lib/adapters/react-dom/HaikuReactDOMAdapter.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) Haiku 2016-2018. All rights reserved.
 */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var React = __webpack_require__("../node_modules/react/cjs/react.development.js");
var ReactDOM = __webpack_require__("../node_modules/react-dom/cjs/react-dom.development.js");
var Config_1 = __webpack_require__("../node_modules/@haiku/core/lib/Config.js");
var getParsedProperty_1 = __webpack_require__("../node_modules/@haiku/core/lib/helpers/getParsedProperty.js");
var StringUtils_1 = __webpack_require__("../node_modules/@haiku/core/lib/helpers/StringUtils.js");
var EventsDict_1 = __webpack_require__("../node_modules/@haiku/core/lib/adapters/react-dom/EventsDict.js");
var DEFAULT_HOST_ELEMENT_TAG_NAME = 'div';
// tslint:disable-next-line:function-name
function HaikuReactDOMAdapter(haikuComponentFactory, optionalRawBytecode) {
    var HaikuReactComponentInternal = /** @class */ (function (_super) {
        __extends(HaikuReactComponentInternal, _super);
        function HaikuReactComponentInternal(props) {
            var _this = _super.call(this, props) || this;
            _this.state = {
                // This random id is used to give us a hook to query the DOM for our mount element,
                // even in cases where React mysteriously decides not to pass us its ref.
                randomId: 'haiku-reactroot-' + StringUtils_1.randomString(24),
            };
            return _this;
        }
        HaikuReactComponentInternal.prototype.componentWillReceiveProps = function (nextPropsRaw) {
            if (this.haiku) {
                var haikuConfig = this.buildHaikuCompatibleConfigFromRawProps(nextPropsRaw);
                this.haiku.assignConfig(haikuConfig);
            }
        };
        HaikuReactComponentInternal.prototype.componentWillUnmount = function () {
            if (this.haiku) {
                this.haiku.callUnmount();
            }
        };
        HaikuReactComponentInternal.prototype.componentDidMount = function () {
            this.attemptMount();
        };
        HaikuReactComponentInternal.prototype.attemptMount = function () {
            if (this.mount) {
                this.createContext(this.props);
            }
        };
        HaikuReactComponentInternal.prototype.buildHaikuCompatibleConfigFromRawProps = function (rawProps) {
            // Note that these vanities are called _after_ an initial render,
            // i.e., after this.mount is supposed to have been attached.
            var haikuConfig = {
                ref: this.mount,
                vanities: {
                    'controlFlow.placeholder': function _controlFlowPlaceholderReactVanity(element, surrogate, value, context, timeline, receiver, sender) {
                        visit(this.mount, function (node) {
                            var flexId = flexIdIfSame(element, node);
                            if (flexId) {
                                if (element.__memory.placeholder.surrogate !== surrogate) {
                                    if (typeof surrogate.type === 'string' ||
                                        (typeof surrogate.type === 'function' && surrogate.type.isHaikuAdapter)) {
                                        // What *should happen* in the DOM renderer is:
                                        // this new swapped DOM element will be updated (not replaced!)
                                        // with the attributes of the virtual element at the same position
                                        var div = document.createElement('div');
                                        node.parentNode.replaceChild(div, node);
                                        // tslint:disable-next-line:no-parameter-reassignment
                                        node = div;
                                    }
                                    node.style.visibility = 'hidden';
                                    ReactDOM.render(surrogate, node);
                                    window.requestAnimationFrame(function () {
                                        element.__memory.placeholder.surrogate = surrogate;
                                        node.style.visibility = 'visible';
                                    });
                                    sender.markHorizonElement(element);
                                    sender.markForFullFlush();
                                }
                            }
                        });
                    }.bind(this),
                },
            };
            // It's assumed that anything the user wants to pass into the Haiku engine should be
            // assigned among the whitelisted properties
            if (rawProps) {
                for (var verboseKeyName in rawProps) {
                    // We already should have subscribed at the React host element level;
                    // we don't pass in otherwise we can end up with multiple events fired
                    if (EventsDict_1.default[verboseKeyName]) {
                        continue;
                    }
                    haikuConfig = __assign({}, haikuConfig, getParsedProperty_1.default(rawProps, verboseKeyName));
                }
            }
            return haikuConfig;
        };
        HaikuReactComponentInternal.prototype.createContext = function (rawProps) {
            var haikuConfig = this.buildHaikuCompatibleConfigFromRawProps(rawProps);
            var haikuAdapter;
            if (rawProps.haikuAdapter) {
                if (rawProps.haikuCode) {
                    haikuAdapter = rawProps.haikuAdapter(rawProps.haikuCode);
                }
                else if (optionalRawBytecode) {
                    haikuAdapter = rawProps.haikuAdapter(optionalRawBytecode);
                }
                else {
                    throw new Error('A Haiku code object is required if you supply a Haiku adapter');
                }
            }
            else {
                // Otherwise default to the adapter which was initialized in the wrapper module
                haikuAdapter = haikuComponentFactory;
            }
            if (!haikuAdapter) {
                throw new Error('A Haiku adapter is required');
            }
            // Reuse existing mounted component if one exists
            if (!this.haiku) {
                this.haiku = haikuAdapter(// eslint-disable-line
                this.mount, haikuConfig);
            }
            else {
                // If the component already exists, update its options and make sure it remounts.
                // This action is important if we are in e.g. React Router.
                //
                // Important: Note that we should NOT call remount if we just initialized the instance (i.e. stanza above)
                // because we'll end up pausing the timelines before the first mount, resulting in a blank context.
                this.haiku.callRemount(haikuConfig);
            }
        };
        HaikuReactComponentInternal.prototype.buildHostElementPropsFromRawProps = function (rawProps) {
            var _this = this;
            var propsForReactHostElement = {};
            var _loop_1 = function (key) {
                if (willReactProbablyHandleProp(rawProps[key], key)) {
                    if (EventsDict_1.default[key]) {
                        // We wrap it because listeners expect to receive the Haiku component
                        // instance as an argument; and for convenience we provide the native
                        // event in addition to it and React's proxy
                        propsForReactHostElement[key] = function (proxy) {
                            return rawProps[key].call(_this, proxy, proxy && proxy.nativeEvent, _this.haiku);
                        };
                    }
                    else {
                        propsForReactHostElement[key] = rawProps[key];
                    }
                }
            };
            for (var key in rawProps) {
                _loop_1(key);
            }
            // Style objects are excluded above, but we definitely want it if provided
            var stylesForHostElement = rawProps.style || {};
            // Merge our basic host props with some defaults we want to assign
            return __assign({ id: this.state.randomId, style: __assign({ position: 'relative', margin: 0, padding: 0, border: 0, width: '100%', height: '100%', transform: 'matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)' }, stylesForHostElement) }, propsForReactHostElement);
        };
        HaikuReactComponentInternal.prototype.assignMountFromRef = function (element) {
            this.mount = element;
        };
        HaikuReactComponentInternal.prototype.render = function () {
            var _this = this;
            var hostElementProps = this.buildHostElementPropsFromRawProps(this.props);
            // Having this ref assigned like this is critical to the adapter working,
            // so we override it despite what the host element props might say
            hostElementProps.ref = function (element) {
                _this.assignMountFromRef(element);
            };
            return React.createElement(hostElementProps.tagName || DEFAULT_HOST_ELEMENT_TAG_NAME, hostElementProps);
        };
        HaikuReactComponentInternal.React = React;
        HaikuReactComponentInternal.ReactDOM = ReactDOM;
        // This setting is required to do proper setup for placeholder/inject vanities
        HaikuReactComponentInternal.isHaikuAdapter = true;
        return HaikuReactComponentInternal;
    }(React.Component));
    return HaikuReactComponentInternal;
}
exports.default = HaikuReactDOMAdapter;
function willReactProbablyHandleProp(prop, key) {
    // Exclude any 'complex' properties like objects
    if (prop && typeof prop === 'object') {
        return false;
    }
    // Assume functions, which are usually event listeners, are handled by Haiku
    if (typeof prop === 'function') {
        if (EventsDict_1.default[key]) {
            return true;
        }
        return false;
    }
    // Exclude props we know target Haiku config
    return !Config_1.DEFAULTS.hasOwnProperty(key);
}
function visit(el, visitor) {
    if (el) {
        visitor(el);
        if (el.children) {
            for (var i = 0; i < el.children.length; i++) {
                visit(el.children[i], visitor);
            }
        }
    }
}
function flexIdIfSame(virtual, dom) {
    if (virtual.attributes) {
        if (virtual.attributes['haiku-id']) {
            if (dom.getAttribute('haiku-id') === virtual.attributes['haiku-id']) {
                return virtual.attributes['haiku-id'];
            }
        }
        if (virtual.attributes.id) {
            if (dom.getAttribute('id') === virtual.attributes.id) {
                return virtual.attributes.id;
            }
        }
    }
    return null;
}
//# sourceMappingURL=HaikuReactDOMAdapter.js.map

/***/ }),

/***/ "../node_modules/@haiku/core/lib/adapters/react-dom/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Copyright (c) Haiku 2016-2018. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
var HaikuReactDOMAdapter_1 = __webpack_require__("../node_modules/@haiku/core/lib/adapters/react-dom/HaikuReactDOMAdapter.js");
exports.default = HaikuReactDOMAdapter_1.default;
//# sourceMappingURL=index.js.map

/***/ })

})
//# sourceMappingURL=0.abaefa3e9a1c94f2e753.hot-update.js.map